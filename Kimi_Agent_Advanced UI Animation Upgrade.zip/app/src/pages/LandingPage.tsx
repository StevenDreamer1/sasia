import Navigation from '../sections/Navigation';
import Hero from '../sections/Hero';
import HowItWorks from '../sections/HowItWorks';
import Services from '../sections/Services';
import Pricing from '../sections/Pricing';
import Testimonials from '../sections/Testimonials';
import CTA from '../sections/CTA';
import Footer from '../sections/Footer';

const LandingPage = () => {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <main>
        <Hero />
        <HowItWorks />
        <Services />
        <Pricing />
        <Testimonials />
        <CTA />
      </main>
      <Footer />
    </div>
  );
};

export default LandingPage;
