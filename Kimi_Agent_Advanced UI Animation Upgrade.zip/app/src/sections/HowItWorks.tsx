import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Upload, MessageSquare, Download, Check } from 'lucide-react';
import { motion } from 'framer-motion';

gsap.registerPlugin(ScrollTrigger);

const steps = [
  {
    number: '01',
    icon: Upload,
    title: 'Submit Request',
    description: 'Fill out a simple brief, choose your service, and upload your raw files directly to our secure vault.',
    color: 'from-purple-500 to-purple-600',
  },
  {
    number: '02',
    icon: MessageSquare,
    title: 'Chat with Editors',
    description: 'Discuss your vision in real-time with your dedicated editor via our built-in studio chat.',
    color: 'from-blue-500 to-blue-600',
  },
  {
    number: '03',
    icon: Download,
    title: 'Review & Download',
    description: 'Get notified instantly when your project is ready. Review, approve, and download the final asset.',
    color: 'from-pink-500 to-pink-600',
  },
];

const HowItWorks = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Staggered card reveal
      const cards = cardsRef.current?.querySelectorAll('.step-card');
      if (cards) {
        gsap.fromTo(cards,
          { opacity: 0, y: 60, rotateY: -15 },
          {
            opacity: 1,
            y: 0,
            rotateY: 0,
            duration: 0.8,
            stagger: 0.15,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 70%',
              toggleActions: 'play none none none',
            },
          }
        );
      }

      // Connector line animation
      gsap.fromTo('.connector-line',
        { strokeDashoffset: 200 },
        {
          strokeDashoffset: 0,
          duration: 1,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: cardsRef.current,
            start: 'top 60%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="features"
      className="section-padding bg-white relative overflow-hidden"
    >
      {/* Background Decoration */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-purple-50 rounded-full blur-3xl opacity-50 -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-50 rounded-full blur-3xl opacity-50 translate-y-1/2 -translate-x-1/2" />

      <div className="container-custom relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-4xl md:text-5xl font-bold font-['Outfit'] text-gray-900 mb-4"
          >
            How Sasia Works
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-lg text-gray-600 max-w-xl mx-auto"
          >
            Stop emailing zip files. Start managing projects like a pro.
          </motion.p>
        </div>

        {/* Steps Grid */}
        <div ref={cardsRef} className="relative">
          {/* Connector Line (Desktop) */}
          <svg
            className="absolute top-1/2 left-0 right-0 h-2 -translate-y-1/2 hidden lg:block"
            style={{ zIndex: 0 }}
          >
            <line
              x1="16.66%"
              y1="50%"
              x2="83.33%"
              y2="50%"
              stroke="#e5e7eb"
              strokeWidth="2"
              strokeDasharray="8 4"
            />
            <line
              className="connector-line"
              x1="16.66%"
              y1="50%"
              x2="83.33%"
              y2="50%"
              stroke="#7c3aed"
              strokeWidth="2"
              strokeDasharray="200"
              strokeDashoffset="200"
            />
          </svg>

          <div className="grid md:grid-cols-3 gap-8 relative z-10">
            {steps.map((step) => (
              <motion.div
                key={step.number}
                className="step-card group"
                whileHover={{ y: -8, scale: 1.02 }}
                transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              >
                <div className="bg-white rounded-2xl p-8 border border-gray-100 shadow-lg hover:shadow-2xl transition-all duration-500 relative overflow-hidden">
                  {/* Gradient Background on Hover */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${step.color} opacity-0 group-hover:opacity-5 transition-opacity duration-500`} />

                  {/* Number Badge */}
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${step.color} flex items-center justify-center mb-6 shadow-lg group-hover:shadow-xl transition-shadow duration-300`}>
                    <span className="text-white font-bold text-lg">{step.number}</span>
                  </div>

                  {/* Icon */}
                  <div className="mb-4">
                    <step.icon className="w-8 h-8 text-purple-600 group-hover:scale-110 group-hover:rotate-3 transition-transform duration-300" />
                  </div>

                  {/* Content */}
                  <h3 className="text-xl font-bold font-['Outfit'] text-gray-900 mb-3">
                    {step.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed">
                    {step.description}
                  </p>

                  {/* Check Indicator */}
                  <div className="mt-6 flex items-center gap-2 text-purple-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <Check className="w-5 h-5" />
                    <span className="text-sm font-medium">Simple & Secure</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Bottom Stats */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8"
        >
          {[
            { value: '500+', label: 'Happy Creators' },
            { value: '10K+', label: 'Projects Completed' },
            { value: '4.9', label: 'Average Rating' },
            { value: '24h', label: 'Avg. Turnaround' },
          ].map((stat, idx) => (
            <div key={idx} className="text-center">
              <div className="text-3xl md:text-4xl font-bold font-['Outfit'] text-gradient mb-2">
                {stat.value}
              </div>
              <div className="text-sm text-gray-600">{stat.label}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default HowItWorks;
