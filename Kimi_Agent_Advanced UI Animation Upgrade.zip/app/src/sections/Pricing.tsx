import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Check, Sparkles, Zap, Crown } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

gsap.registerPlugin(ScrollTrigger);

const plans = [
  {
    name: 'Starter',
    description: 'Weekly Pass',
    price: '499',
    period: 'week',
    icon: Zap,
    features: [
      '1 video project per week',
      'Basic editing & cuts',
      '48-hour turnaround',
      '2 revision rounds',
      'Email support',
    ],
    notIncluded: [
      'Thumbnail design',
      'Priority support',
    ],
    cta: 'Get Started',
    popular: false,
  },
  {
    name: 'Monthly Pro',
    description: 'Most Popular',
    price: '1,699',
    period: 'month',
    icon: Sparkles,
    features: [
      'Unlimited video projects',
      'Advanced editing & effects',
      '24-hour turnaround',
      'Unlimited revisions',
      'Thumbnail design included',
      'Priority chat support',
      'Dedicated editor',
    ],
    notIncluded: [],
    cta: 'Start Free Trial',
    popular: true,
  },
  {
    name: 'Yearly Elite',
    description: 'Best Value',
    price: '9,999',
    period: 'year',
    icon: Crown,
    features: [
      'Everything in Pro',
      'Audio mixing included',
      'Shorts/Reels optimization',
      'Same-day turnaround',
      'Video strategy calls',
      'White-label delivery',
      'API access',
    ],
    notIncluded: [],
    cta: 'Go Elite',
    popular: false,
  },
];

const Pricing = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [hoveredPlan, setHoveredPlan] = useState<number | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Price counter animation
      const priceElements = document.querySelectorAll('.price-number');
      priceElements.forEach((el) => {
        const target = parseInt(el.getAttribute('data-value') || '0');
        gsap.fromTo(el,
          { textContent: 0 },
          {
            textContent: target,
            duration: 1.5,
            ease: 'power2.out',
            snap: { textContent: 1 },
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 70%',
              toggleActions: 'play none none none',
            },
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="pricing"
      className="section-padding bg-gray-50 relative overflow-hidden"
    >
      {/* Background Decoration */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-gradient-to-b from-purple-100 to-transparent rounded-full blur-3xl opacity-40" />

      <div className="container-custom relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-4xl md:text-5xl font-bold font-['Outfit'] text-gray-900 mb-4"
          >
            Simple, Transparent Pricing
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: 0.15 }}
            className="text-lg text-gray-600 max-w-xl mx-auto"
          >
            Just start work at ₹499/week and you will access all services.
          </motion.p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 60 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ 
                duration: 0.6, 
                delay: index * 0.15,
                ease: [0.16, 1, 0.3, 1]
              }}
              onMouseEnter={() => setHoveredPlan(index)}
              onMouseLeave={() => setHoveredPlan(null)}
              className={`relative ${plan.popular ? 'md:-mt-4 md:mb-4' : ''}`}
            >
              {/* Popular Badge */}
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-20">
                  <span className="bg-gradient-to-r from-purple-600 to-purple-700 text-white text-xs font-bold px-4 py-1.5 rounded-full shadow-lg">
                    MOST POPULAR
                  </span>
                </div>
              )}

              <motion.div
                whileHover={{ y: -10 }}
                transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                className={`bg-white rounded-2xl p-8 h-full relative overflow-hidden ${
                  plan.popular
                    ? 'shadow-2xl border-2 border-purple-200 animate-featured-pulse'
                    : 'shadow-lg border border-gray-100 hover:shadow-xl'
                } transition-shadow duration-500`}
              >
                {/* Plan Icon */}
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-6 ${
                  plan.popular ? 'bg-purple-100' : 'bg-gray-100'
                }`}>
                  <plan.icon className={`w-6 h-6 ${
                    plan.popular ? 'text-purple-600' : 'text-gray-600'
                  }`} />
                </div>

                {/* Plan Name */}
                <h3 className="text-xl font-bold font-['Outfit'] text-gray-900 mb-1">
                  {plan.name}
                </h3>
                <p className="text-sm text-gray-500 mb-6">{plan.description}</p>

                {/* Price */}
                <div className="mb-8">
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-medium text-gray-900">₹</span>
                    <span 
                      className="price-number text-5xl font-bold font-['Outfit'] text-gray-900"
                      data-value={plan.price.replace(',', '')}
                    >
                      {plan.price}
                    </span>
                  </div>
                  <span className="text-gray-500 text-sm">/{plan.period}</span>
                </div>

                {/* Features */}
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, i) => (
                    <motion.li
                      key={i}
                      initial={{ opacity: 0, x: -10 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.3 + i * 0.05 }}
                      className="flex items-start gap-3"
                    >
                      <Check className={`w-5 h-5 mt-0.5 flex-shrink-0 ${
                        plan.popular ? 'text-purple-600' : 'text-green-500'
                      }`} />
                      <span className="text-sm text-gray-600">{feature}</span>
                    </motion.li>
                  ))}
                  {plan.notIncluded.map((feature, i) => (
                    <li key={`not-${i}`} className="flex items-start gap-3 opacity-50">
                      <div className="w-5 h-5 mt-0.5 flex-shrink-0 rounded-full border-2 border-gray-300" />
                      <span className="text-sm text-gray-400 line-through">{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* CTA Button */}
                <button
                  onClick={() => navigate('/register')}
                  className={`w-full py-3 px-6 rounded-xl font-semibold transition-all duration-300 ${
                    plan.popular
                      ? 'bg-purple-600 text-white hover:bg-purple-700 hover:shadow-lg hover:shadow-purple-200'
                      : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                  }`}
                >
                  {plan.cta}
                </button>

                {/* Hover Glow Effect */}
                {hoveredPlan === index && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-transparent pointer-events-none"
                  />
                )}
              </motion.div>
            </motion.div>
          ))}
        </div>

        {/* Bottom Note */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="mt-12 text-center"
        >
          <p className="text-sm text-gray-500">
            All plans include secure file storage, project history, and 24/7 access to your dashboard.
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default Pricing;
