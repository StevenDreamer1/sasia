import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Video, Image, Film, Headphones, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

gsap.registerPlugin(ScrollTrigger);

const services = [
  {
    icon: Video,
    title: 'Video Editing',
    description: 'Professional video editing with color grading, transitions, and effects that make your content stand out.',
    color: 'from-purple-500 to-purple-600',
    bgColor: 'bg-purple-50',
  },
  {
    icon: Image,
    title: 'Thumbnail Design',
    description: 'Eye-catching thumbnails that boost your click-through rates and make viewers stop scrolling.',
    color: 'from-blue-500 to-blue-600',
    bgColor: 'bg-blue-50',
  },
  {
    icon: Film,
    title: 'Shorts/Reels',
    description: 'Vertical video optimization for TikTok, Instagram Reels, and YouTube Shorts with trending styles.',
    color: 'from-pink-500 to-pink-600',
    bgColor: 'bg-pink-50',
  },
  {
    icon: Headphones,
    title: 'Audio Mixing',
    description: 'Crystal clear audio with noise reduction, leveling, and professional sound design.',
    color: 'from-amber-500 to-amber-600',
    bgColor: 'bg-amber-50',
  },
];

const Services = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const ctx = gsap.context(() => {
      // 3D flip entrance animation
      const cards = cardsRef.current?.querySelectorAll('.service-card');
      if (cards) {
        gsap.fromTo(cards,
          { 
            opacity: 0, 
            rotateY: -90,
            transformPerspective: 800,
          },
          {
            opacity: 1,
            rotateY: 0,
            duration: 0.6,
            stagger: 0.12,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 70%',
              toggleActions: 'play none none none',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="services"
      className="section-padding bg-white relative overflow-hidden"
    >
      {/* Background Decoration */}
      <div className="absolute top-1/2 left-0 w-[500px] h-[500px] bg-gradient-to-r from-purple-100 to-transparent rounded-full blur-3xl opacity-40 -translate-y-1/2 -translate-x-1/2" />

      <div className="container-custom relative z-10">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-16">
          <div>
            <motion.div
              initial={{ scaleX: 0 }}
              whileInView={{ scaleX: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: 0.2 }}
              className="w-16 h-1 bg-purple-600 rounded-full mb-6 origin-left"
            />
            <motion.h2
              initial={{ opacity: 0, x: -40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="text-4xl md:text-5xl font-bold font-['Outfit'] text-gray-900 mb-4"
            >
              Services We Offer
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: 0.3 }}
              className="text-lg text-gray-600 max-w-md"
            >
              Everything you need to grow your channel.
            </motion.p>
          </div>
          <motion.button
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: 0.4 }}
            onClick={() => {
              const element = document.querySelector('#pricing');
              element?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="mt-6 md:mt-0 text-purple-600 font-medium flex items-center gap-2 group hover:gap-3 transition-all"
          >
            See full pricing
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </motion.button>
        </div>

        {/* Services Grid */}
        <div ref={cardsRef} className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service) => (
            <motion.div
              key={service.title}
              className="service-card group"
              style={{ 
                transformStyle: 'preserve-3d',
                perspective: '800px',
              }}
              whileHover={{ 
                y: -12,
                transition: { duration: 0.4, ease: [0.16, 1, 0.3, 1] }
              }}
            >
              <div className="bg-white rounded-2xl p-8 border border-gray-100 h-full relative overflow-hidden hover:shadow-2xl transition-all duration-500">
                {/* Gradient Overlay */}
                <div className={`absolute inset-0 bg-gradient-to-br ${service.color} opacity-0 group-hover:opacity-[0.03] transition-opacity duration-500`} />

                {/* Icon */}
                <div className={`w-14 h-14 ${service.bgColor} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-3 transition-all duration-300`}>
                  <service.icon className={`w-7 h-7 bg-gradient-to-br ${service.color} text-transparent bg-clip-text`} style={{ color: service.color.includes('purple') ? '#7c3aed' : service.color.includes('blue') ? '#3b82f6' : service.color.includes('pink') ? '#ec4899' : '#f59e0b' }} />
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold font-['Outfit'] text-gray-900 mb-3 group-hover:text-purple-600 transition-colors">
                  {service.title}
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed mb-6">
                  {service.description}
                </p>

                {/* CTA */}
                <button
                  onClick={() => navigate('/register')}
                  className="flex items-center gap-2 text-purple-600 font-medium text-sm group/btn"
                >
                  Start Project
                  <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-2 transition-transform" />
                </button>

                {/* Decorative Corner */}
                <div className={`absolute -bottom-4 -right-4 w-24 h-24 bg-gradient-to-br ${service.color} opacity-10 rounded-full blur-2xl group-hover:opacity-20 transition-opacity`} />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-16 text-center"
        >
          <p className="text-gray-600 mb-4">
            Need something custom? We also offer motion graphics, color grading, and more.
          </p>
          <button
            onClick={() => navigate('/register')}
            className="text-purple-600 font-medium underline-animation"
          >
            Let's talk about your project
          </button>
        </motion.div>
      </div>
    </section>
  );
};

export default Services;
