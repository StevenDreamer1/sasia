import { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Sparkles, Youtube, Instagram, Facebook, Twitter } from 'lucide-react';
import { motion } from 'framer-motion';

gsap.registerPlugin(ScrollTrigger);

const Hero = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Parallax effect on scroll
      gsap.to(contentRef.current, {
        y: -80,
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '50% top',
          scrub: 1,
        },
      });

      // Headline clip-path reveal
      if (headlineRef.current) {
        gsap.fromTo(headlineRef.current,
          { clipPath: 'inset(0 100% 0 0)' },
          {
            clipPath: 'inset(0 0% 0 0)',
            duration: 0.8,
            delay: 0.5,
            ease: 'expo.out',
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const socialIcons = [
    { Icon: Youtube, color: 'hover:text-red-600' },
    { Icon: Instagram, color: 'hover:text-pink-600' },
    { Icon: Facebook, color: 'hover:text-blue-600' },
    { Icon: Twitter, color: 'hover:text-gray-900' },
  ];

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-white pt-20"
    >
      {/* Gradient Orbs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          className="gradient-orb gradient-orb-purple w-[600px] h-[600px] -top-40 -left-40 animate-orb-drift"
        />
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.2, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          className="gradient-orb gradient-orb-blue w-[500px] h-[500px] top-1/3 -right-40 animate-orb-drift"
          style={{ animationDelay: '5s' }}
        />
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.2, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="gradient-orb gradient-orb-pink w-[400px] h-[400px] bottom-20 left-1/4 animate-orb-drift"
          style={{ animationDelay: '10s' }}
        />
      </div>

      {/* Content */}
      <div ref={contentRef} className="container-custom relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-purple-50 rounded-full mb-8"
          >
            <Sparkles className="w-4 h-4 text-purple-600 animate-sparkle" />
            <span className="text-sm font-medium text-purple-700">
              Accepting New Clients for 2026
            </span>
          </motion.div>

          {/* Headline */}
          <h1
            ref={headlineRef}
            className="text-5xl md:text-6xl lg:text-7xl font-bold font-['Outfit'] text-gray-900 mb-6 leading-tight"
          >
            Your Creative Team,{' '}
            <span className="text-gradient">On Autopilot.</span>
          </h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.7 }}
            className="text-lg md:text-xl text-gray-600 mb-10 max-w-2xl mx-auto leading-relaxed"
          >
            Get high-end video editing, graphic design, and audio engineering without the freelance chaos. 
            A dedicated studio dashboard just for creators.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, delay: 0.9, ease: [0.34, 1.56, 0.64, 1] }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12"
          >
            <button
              onClick={() => navigate('/register')}
              className="btn-primary flex items-center gap-2 group"
            >
              Get Started Now
              <ArrowRight className="w-5 h-5 animate-arrow-bounce" />
            </button>
            <button
              onClick={() => {
                const element = document.querySelector('#pricing');
                element?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="btn-secondary"
            >
              View Pricing
            </button>
          </motion.div>

          {/* Social Proof */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 1.1 }}
            className="flex items-center justify-center gap-6"
          >
            <span className="text-sm text-gray-500">Trusted by creators on:</span>
            <div className="flex items-center gap-4">
              {socialIcons.map(({ Icon, color }, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0, rotate: -10 }}
                  animate={{ opacity: 1, scale: 1, rotate: 0 }}
                  transition={{
                    duration: 0.3,
                    delay: 1.2 + index * 0.08,
                    ease: [0.68, -0.55, 0.265, 1.55],
                  }}
                  className={`text-gray-400 ${color} cursor-pointer transition-colors duration-300`}
                >
                  <Icon className="w-6 h-6" />
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Floating Particles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0 }}
            animate={{
              opacity: [0, 0.3, 0],
              y: [0, -100],
              x: [0, (i % 2 === 0 ? 50 : -50)],
            }}
            transition={{
              duration: 8 + i * 2,
              repeat: Infinity,
              delay: i * 1.5,
              ease: 'linear',
            }}
            className="absolute w-2 h-2 bg-purple-400 rounded-full"
            style={{
              left: `${15 + i * 15}%`,
              bottom: '10%',
            }}
          />
        ))}
      </div>
    </section>
  );
};

export default Hero;
