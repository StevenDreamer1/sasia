import { motion } from 'framer-motion';
import { ArrowRight, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface AnimatedButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  showArrow?: boolean;
  isLoading?: boolean;
  className?: string;
  onClick?: () => void;
  type?: 'button' | 'submit';
}

export function AnimatedButton({
  children,
  variant = 'primary',
  size = 'md',
  showArrow = false,
  isLoading = false,
  className,
  onClick,
  type = 'button',
}: AnimatedButtonProps) {
  const baseStyles = 'relative inline-flex items-center justify-center gap-2 font-semibold rounded-lg transition-all duration-300 overflow-hidden group';
  
  const variants = {
    primary: 'bg-purple-600 text-white hover:bg-purple-700 hover:shadow-glow-lg',
    secondary: 'border border-gray-200 text-gray-800 hover:border-purple-600 hover:text-purple-600 hover:bg-purple-50',
    ghost: 'text-gray-600 hover:text-purple-600',
  };
  
  const sizes = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-6 py-3 text-base',
    lg: 'px-8 py-4 text-lg',
  };

  return (
    <motion.button
      type={type}
      onClick={onClick}
      className={cn(baseStyles, variants[variant], sizes[size], className)}
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.98 }}
      disabled={isLoading}
    >
      {/* Shimmer effect */}
      {variant === 'primary' && (
        <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/20 to-transparent" />
      )}
      
      {isLoading ? (
        <Loader2 className="w-5 h-5 animate-spin" />
      ) : (
        <>
          {children}
          {showArrow && (
            <motion.span
              className="inline-block"
              initial={{ x: 0 }}
              whileHover={{ x: 4 }}
              transition={{ duration: 0.2 }}
            >
              <ArrowRight className="w-4 h-4" />
            </motion.span>
          )}
        </>
      )}
    </motion.button>
  );
}
