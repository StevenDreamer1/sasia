import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface GradientTextProps {
  children: React.ReactNode;
  className?: string;
  animate?: boolean;
  from?: string;
  to?: string;
}

export function GradientText({
  children,
  className,
  animate = false,
  from = '#7c3aed',
  to = '#ec4899',
}: GradientTextProps) {
  return (
    <motion.span
      className={cn(
        'bg-clip-text text-transparent',
        animate && 'animate-gradient',
        className
      )}
      style={{
        backgroundImage: `linear-gradient(135deg, ${from}, ${to})`,
        backgroundSize: animate ? '200% 200%' : '100% 100%',
      }}
    >
      {children}
    </motion.span>
  );
}
