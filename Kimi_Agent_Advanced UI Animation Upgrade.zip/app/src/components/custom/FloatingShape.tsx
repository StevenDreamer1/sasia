import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface FloatingShapeProps {
  type: 'circle' | 'square' | 'triangle';
  size?: number;
  color?: string;
  className?: string;
  duration?: number;
  delay?: number;
}

export function FloatingShape({
  type,
  size = 100,
  color = 'rgba(124, 58, 237, 0.2)',
  className,
  duration = 6,
  delay = 0,
}: FloatingShapeProps) {
  const shapeStyles = {
    circle: 'rounded-full',
    square: 'rounded-lg rotate-45',
    triangle: 'clip-path-triangle',
  };

  return (
    <motion.div
      className={cn('absolute pointer-events-none', shapeStyles[type], className)}
      style={{
        width: size,
        height: size,
        background: type === 'triangle' ? 'transparent' : color,
        border: type === 'triangle' ? 'none' : `2px solid ${color}`,
      }}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ 
        opacity: 1, 
        scale: 1,
        y: [0, -20, 0],
        rotate: type === 'square' ? [45, 55, 45] : [0, 10, 0],
      }}
      transition={{
        opacity: { duration: 0.5, delay },
        scale: { duration: 0.5, delay },
        y: { duration, repeat: Infinity, ease: 'easeInOut', delay },
        rotate: { duration: duration * 1.5, repeat: Infinity, ease: 'easeInOut', delay },
      }}
    >
      {type === 'triangle' && (
        <svg width={size} height={size} viewBox="0 0 100 100">
          <polygon
            points="50,10 90,90 10,90"
            fill={color}
          />
        </svg>
      )}
    </motion.div>
  );
}
