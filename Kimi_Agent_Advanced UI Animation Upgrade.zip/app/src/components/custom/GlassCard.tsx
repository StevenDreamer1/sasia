import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  hoverEffect?: boolean;
  glowColor?: string;
  delay?: number;
}

export function GlassCard({
  children,
  className,
  hoverEffect = true,
  glowColor = 'rgba(124, 58, 237, 0.2)',
  delay = 0,
}: GlassCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ 
        duration: 0.6, 
        delay,
        ease: [0.16, 1, 0.3, 1] 
      }}
      whileHover={hoverEffect ? { 
        y: -10, 
        scale: 1.02,
        transition: { duration: 0.3 }
      } : {}}
      className={cn(
        'relative rounded-2xl backdrop-blur-xl bg-white/90 border border-white/20',
        'shadow-card transition-shadow duration-300',
        hoverEffect && 'hover:shadow-card-hover hover:border-purple-200',
        className
      )}
      style={{
        boxShadow: hoverEffect ? `0 4px 20px rgba(0,0,0,0.08), 0 0 0 1px rgba(255,255,255,0.5) inset` : undefined,
      }}
    >
      {/* Glow effect on hover */}
      {hoverEffect && (
        <div 
          className="absolute inset-0 rounded-2xl opacity-0 hover:opacity-100 transition-opacity duration-300 -z-10"
          style={{ 
            boxShadow: `0 20px 60px ${glowColor}`,
          }}
        />
      )}
      {children}
    </motion.div>
  );
}
